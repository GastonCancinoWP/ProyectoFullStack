import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insercion',
  templateUrl: './insercion.component.html',
  styleUrls: ['./insercion.component.css']
})
export class InsercionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
