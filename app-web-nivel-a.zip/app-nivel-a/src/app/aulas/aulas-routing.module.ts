import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// importados por usuario
import { ListadoComponent } from './listado/listado.component'
import { EdicionComponent } from './edicion/edicion.component'
import { InsercionComponent } from './insercion/insercion.component'

const routes: Routes = [
  { path: 'aulas', component: ListadoComponent },            // ahora si funciona ok
  { path: 'aulas/edicion', component: EdicionComponent },    // ahora si funciona ok
  { path: 'aulas/insercion', component: InsercionComponent } // ahora si funciona ok
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AulasRoutingModule { }
