import { Component, OnInit, ViewChild } from '@angular/core';
// importado por usuario
import { AulasService } from '../../servicios/aulas.service';
import { Subscription, Observable } from 'rxjs';
import { NgForm } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit{ //

  // con la referencia # que agregamos en el form, utilizamos el decorador viewchild para obtener la info en JSON
  @ViewChild("f", {static: true}) form: NgForm
  grupo: FormGroup
  
  aulas: any[];

  subscripcionAulas: Subscription;

  constructor(private aulasService: AulasService) { }

  ngOnInit() {

    this.grupo = new FormGroup({
      nombreAula: new FormControl(null, Validators.required),
      gradoAula: new FormControl(null, Validators.required),
      coddescAula: new FormControl(null, Validators.required)
    })

    this.listarAulas()
  }

  listarAulas(){
    this.subscripcionAulas = this.aulasService.listar()
      .subscribe(
        (data: any) => this.aulas = data.results
      )
  }

  agregarAula(){
    if(this.form.valid){
      console.log(this.form.value)
      console.log("formulario ok")

      this.aulasService.insertar(this.grupo.getRawValue()) //  this.grupo.getRawValue()
        .subscribe(
          respuesta => {
            this.grupo.reset()
            this.listarAulas()
            alert("Se insertó el documento")
          }
        )
    } else{
      console.log(this.form.form.getRawValue())
      console.log("formulario invalido")
    }
  }

}
