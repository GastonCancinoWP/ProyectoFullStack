import { Injectable } from '@angular/core';
// importados por usuario
import { HttpClient } from '@angular/common/http';
import { Generico } from './generico';

@Injectable({
  providedIn: 'root'
})
export class AulasService extends Generico {

  constructor(http: HttpClient) {
    super(http, "http://localhost:3000/aulas")
  }

  listar(){
    return this.http.get("http://localhost:3000/aulas")
  }

  insertar(data){
    return this.http.post("http://localhost:3000/aulas", data)
  }

}
