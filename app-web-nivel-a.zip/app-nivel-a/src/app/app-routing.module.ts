import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

// importados por usuario
import { CommonModule } from '@angular/common';
import { UsuariosModule } from './usuarios/usuarios.module';
import { AulasModule } from './aulas/aulas.module';

const rutas: Routes = [
  { path: 'usuarios', loadChildren: () => import('./usuarios/usuarios.module').then(mod => mod.UsuariosModule) },
  { path: 'aulas', loadChildren: () => import('./aulas/aulas.module').then(mod => mod.AulasModule) }
];

@NgModule({
  //imports: [RouterModule.forRoot(routes)],
  imports: [
    RouterModule.forRoot(rutas, {preloadingStrategy: PreloadAllModules}),
    CommonModule,
    // aqui se importa el AulasModule y UsuariosModule para evitar que carguen al inicio y recargar mucho el servidor 
    // ya no va en app.module.ts, ahora van aqui. Esto para llamar a los componentes solo bajo demanda.
    AulasModule,
    UsuariosModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
