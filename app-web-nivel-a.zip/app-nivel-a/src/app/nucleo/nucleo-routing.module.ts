import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// importados por usuario
import { LoginComponent } from './login/login.component';
import { RecuperarComponent } from './recuperar/recuperar.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'recuperar', component: RecuperarComponent },
  { path: '**', component: PageNotFoundComponent }// utilizando el wilcard **, siempre debe ir al final. Para que si
  // se dirigen a cualquier otra ruta los dirija al Page not found.
]

@NgModule({
  imports: [
    //RouterModule.forChild(rutas)
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class NucleoRoutingModule { }
