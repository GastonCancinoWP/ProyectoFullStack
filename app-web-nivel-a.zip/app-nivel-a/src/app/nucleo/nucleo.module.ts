import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NucleoRoutingModule } from './nucleo-routing.module';
import { LoginComponent } from './login/login.component';
import { CabeceraComponent } from './cabecera/cabecera.component';
import { MenuComponent } from './menu/menu.component';
import { RecuperarComponent } from './recuperar/recuperar.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [LoginComponent, CabeceraComponent, MenuComponent, RecuperarComponent, HomeComponent, PageNotFoundComponent],
  imports: [
    CommonModule,
    NucleoRoutingModule
  ],
  exports: [ // exports agregado por usuario
    CabeceraComponent
  ]
})
export class NucleoModule { }
