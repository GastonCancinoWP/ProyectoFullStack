import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuardsRoutingModule } from './guards-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GuardsRoutingModule
  ]
})
export class GuardsModule { }
