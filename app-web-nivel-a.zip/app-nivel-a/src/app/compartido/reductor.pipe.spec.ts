import { ReductorPipe } from './reductor.pipe';

describe('ReductorPipe', () => {
  it('create an instance', () => {
    const pipe = new ReductorPipe();
    expect(pipe).toBeTruthy();
  });
});
