import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//importado por usuario
import { ListadoComponent } from './listado/listado.component';
import { EdicionComponent } from './edicion/edicion.component';
import { InsercionComponent } from './insercion/insercion.component';

const routes: Routes = [
  { path: 'usuarios', component: ListadoComponent },             // funciona perfect !
  { path: 'usuarios/edicion', component: EdicionComponent },     // funciona perfect !
  { path: 'usuarios/insercion', component: InsercionComponent }  // funciona perfect !
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsuariosRoutingModule { }
