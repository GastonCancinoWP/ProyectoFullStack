// importados por usuario
//import { Inicializar } from './bin/app'
import * as app from './bin/app'
import { logger } from './utils/log.utils'
import { iniciarDB } from './services/database.service'

// falto instalar el express pero en nuestro proyecto (ya lo teniamos instalado con
// npm install -g express, osea de forma global pero en cada proyecto se debe instalar tambien)

const iniciar = async () => {
    /*app.inicializar()
        .then(() => console.log("Servidor ejecutándose"))
        .catch(error => console.log(error))*/
    try{
        logger.info("Servidor inicializando")
        await app.inicializar()
        //console.log("Servidor ejecutandose")
        logger.info("Servidor ejecutandose en el puerto 3000")
    } catch(error){
        //console.log(error)
        logger.error(error) // no es necesario ya que estara en un archivo aparte llamado "error.log"
        process.exit(1) // te asegura que NodeJS no se quede con algun archivo abierto al caerse
    }

    try{

        logger.info("Inicializando la conexión con Mongo")
        await iniciarDB()
        logger.info("Mongo conectado")

    } catch(error){
        logger.error(error)
        process.exit(1) // te asegura que NodeJS no se quede con algun archivo abierto al caerse
    }
    
}

iniciar()

const apagar = async (err = null) => {
	let error = err

	try {
        logger.info("Servidor cerrándose")
		//console.log("Servidor cerrándose")
        await app.cerrar()
        logger.info("Servidor cerrado")
		//console.log("Servidor cerrado")
	} catch (err) {
        logger.error("Ocurrió un error al cerrar ", err)
		//console.log("Ocurrió un error al cerrar", err)
		error = error || err
	}

    logger.info("Proceso de cerrado activo")
	//console.log("Proceso de cerrado activo")

	if (error) process.exit(1) // te asegura que NodeJS no se quede con algun archivo abierto al caerse
	else process.exit(0)

}


// el SIGTERM recibe una alerta cuando se presiona CTRL + C
process.on("SIGTERM", () => {
    logger.info("alerta SIGTERM")
    //console.log("alerta SIGTERM")
	apagar()
})

// el SIGTERM recibe una alerta cuando se presiona CTRL + C
process.on("SIGINT", () => {
    logger.info("alerta SIGINT")
    //console.log("alerta SIGINT")
	apagar()
})

process.on("uncaughtException", err => {
    logger.info("alerta uncaughtException")
    //console.log("alerta uncaughtException")
	apagar(err)
})