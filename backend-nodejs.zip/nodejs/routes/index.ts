// todos los archivos index se toman por defecto
export { default as RouteAulas } from './aulas.route'