import * as express from "express";
import * as Joi from '@hapi/joi';
import { validate, AulasSchema } from '../validators';
import { AulasController } from '../controllers';
import { catchAsync } from '../handlers/errors.handler';

const RouteAulas = express.Router()
const aulasController = new AulasController()

RouteAulas.get("/", catchAsync(aulasController.listar))
RouteAulas.post("/", validate(AulasSchema.AULAS_POST_SCHEMA), aulasController.insertar)
RouteAulas.delete("/:_id", aulasController.eliminar)
RouteAulas.put("/:_id", aulasController.modificar)
RouteAulas.get("/:_id", aulasController.detallar)

export default RouteAulas