import mongoose = require("mongoose")
import * as configDatabase from '../config/database.config'
import { logger } from '../utils/log.utils'

const iniciarDB = async() => {
    // primer parametro es la cadena de conexion, segundo parametro es un JSON de opciones
    mongoose.connect(configDatabase.connectionString, {
        keepAlive: true,       // mantener la conexion activa pero un tiempo determinado por los servidores
        useNewUrlParser: true, // le indicamos que use el nuevo parseador, ya no el antiguo
        useCreateIndex: true,
		useUnifiedTopology: true
    })

    // le decimos a mongoose que trabaje con promesas y en particular con la libreria global
    mongoose.Promise = global.Promise

    const promiseConnection = new Promise( (resolve, reject) => {
        mongoose.connection.on("error", error => {
            logger.error(error)
            reject()
        })

        // cuando se conecte
        mongoose.connection.on("connected", () => {
            logger.info("Conectado a Mongo")
            logger.info("Creando modelos")
            
            // creando el modelo "aula"
            require('../models/aula.model')

            logger.info("Modelos creados")
            resolve()
        })
    })

    await promiseConnection
}

export { iniciarDB }