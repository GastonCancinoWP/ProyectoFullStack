export { default as AulasValidators } from './aulas.validator';
export { default as AulasSchema } from './aulas.schema';
export { default as validate } from './validate';