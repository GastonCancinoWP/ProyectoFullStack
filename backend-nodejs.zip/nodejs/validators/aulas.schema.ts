import * as Joi from '@hapi/joi'

class AulasSchema{
    static AULAS_POST_SCHEMA = {
        body: Joi.object({
            nombre: Joi.string().required(),
            grado: Joi.string().required(),
            coddesc: Joi.string().required()
            // ejm con email: Joi.string().regex(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/).required(),
        })

    }

    static AULAS_GET_SCHEMA = {
        params: Joi.object().keys({
			id: Joi.number().required()
		})
    }

    static AULAS_DELETE_SCHEMA = {
        params: Joi.object().keys({
			id: Joi.number().required()
		})
    }

    static AULAS_PUT_SCHEMA = {
        params: Joi.object().keys({
			id: Joi.number().required()
        }),
        body: Joi.object().keys({
			nombre: Joi.string().required(),
			grado: Joi.string().required(),
			coddesc: Joi.string().required(),
			// ejm. no obligatorio campo4: Joi.string()
			// ejm. contrasena: Joi.string().regex(/^[a-z]{2,3}[0-9]{5,5}$/).required(),
			// ejm. campo con sub-registros locales: Joi.array().items(Joi.object().keys({
				//lat: Joi.number().required(),
				//lng: Joi.number().required()
			//})).required()
		})
    }
}

export default AulasSchema