import * as fs from "fs" // para manejar sarchivos en la PC (file system)
import * as path from "path" // para manejar rutas en la PC

// le decimos que el log estara guardado en la carpeta "logs" de la ruta raiz (retrocedimos con ../)
// el metodo join de la libreria path une varios pedazos de una ruta
const rutaDirectorioLog = path.join(__dirname, "../", "logs")

// utilizaremos un metodo SINCRONO para asegurarse de que se este verificando que exista la carpeta
// y mientras este verificando, no hacer nada, esperar
// esto para evitar errores al intentar guardar en una ruta inexistente.

// si existe la ruta o crear el directorio:
fs.existsSync(rutaDirectorioLog) || fs.mkdirSync(rutaDirectorioLog)

export{ rutaDirectorioLog }