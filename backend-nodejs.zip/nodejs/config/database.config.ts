const connectionString = "mongodb+srv://usu1:usu12019@clustamazon201908-jdy7w.mongodb.net/test?retryWrites=true&w=majority"

export { connectionString }