const maxTamano = 5120000 // 5 Megas como maximo por archivo log
const maxArchivos = 5 // 5 archivos como maximo

export { maxTamano, maxArchivos }