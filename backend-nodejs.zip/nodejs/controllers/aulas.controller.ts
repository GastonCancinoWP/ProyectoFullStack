import GenericoController from './generico.controller'
import Aula from '../models/aula.model'

class AulasController extends GenericoController{
    constructor(){
        super(Aula)
    }
}

export default AulasController