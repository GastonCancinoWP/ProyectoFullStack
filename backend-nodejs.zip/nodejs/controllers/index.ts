// todos los archivos index se toman por defecto
export { default as AulasController } from './aulas.controller'