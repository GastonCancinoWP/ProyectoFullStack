class GenericoController{

    constructor(private modelo: any){

        // bind: para que busque el metodo listar en el mabito/contexto original desde donde se esta 
        // llamando
        this.listar = this.listar.bind(this)     // NUNCA !! poner bind(this.listar) NUNCAAA !!!
        this.insertar = this.insertar.bind(this) // NUNCA !! poner bind(this.insertar) NUNCAAA !!!
        this.eliminar = this.eliminar.bind(this) // NUNCA !! poner bind(this.eliminar) NUNCAAA !!!
        this.modificar = this.modificar.bind(this) // NUNCA !! poner bind(this.modificar) NUNCAAA !!!
        this.detallar = this.detallar.bind(this)   // NUNCA !! poner bind(this.detallar) NUNCAAA !!!
    }

    async listar(req, res, next){

        // otorgando permisos a mi servidor de angular para consumir JSON localmente desde mi backend NodeJS:
        // INI - otorgando permisos
            // Website you wish to allow to connect
            res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

            // Request methods you wish to allow
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

            // Request headers you wish to allow
            res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

            // Set to true if you need the website to include cookies in the requests sent
            // to the API (e.g. in case you use sessions)
            res.setHeader('Access-Control-Allow-Credentials', true);
        // FIN - otorgando permisos

        const results = await this.modelo.find()

        res.json({
            createdBy: res.locals.nombre,
            createdById: res.locals._id,
            status: 200,
            message: "Listado de documentos",
            results
        })
    }

    async detallar(req, res){
        const filtro = { _id: req.params._id }

        const result = await this.modelo.findOne(filtro)
        res.json({
            status: 200,
            message: "Detalle del documento",
            result
        }) 
    }

    async modificar(req, res){
        const filtro = { _id: req.params._id }
        const data = req.body

        await this.modelo.updateOne(filtro, data) // updateOne => actualiza solo 1 registro
                                                  // updateMany => actualiza varios registros
        res.status(201).json({
            status: 201,
            message: "Documento modificado"
        })
    }

    async eliminar(req, res){
        const filtro = { _id: req.params._id }

        await this.modelo.deleteOne(filtro) // deleteOne => borra solo 1 registro
                                            // deleteMany => borra varios registros
        res.status(201).json({
            status: 201,
            message: "Documento borrado"
        })
    }

    async insertar(req, res){

        // otorgando permisos a mi servidor de angular para consumir JSON localmente desde mi backend NodeJS:
        // INI - otorgando permisos
            // Website you wish to allow to connect
            res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

            // Request methods you wish to allow
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

            // Request headers you wish to allow
            res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

            // Set to true if you need the website to include cookies in the requests sent
            // to the API (e.g. in case you use sessions)
            res.setHeader('Access-Control-Allow-Credentials', true);
        // FIN - otorgando permisos

        const obj = Object.assign({}, req.body)

		const mod = new this.modelo(obj)
		const result = await mod.save()

		res.status(201).json({
			status: 201,
			message: "Documento insertado",
			result
		})
    }

}

export default GenericoController