const mongoose = require("mongoose")

const esquema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        lowercase: true
    },
    grado: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        lowercase: true
    },
    coddesc: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        lowercase: true
    }
})

const Aula = mongoose.model("Aula", esquema)

export default Aula