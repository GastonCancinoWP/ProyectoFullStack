import * as winston from "winston" // importando la libreria
import * as configLog from "../config/log.config" // importando las configuraciones de cada log
import * as configGeneral from "../config/general.config" // importando las configuraciones generales

// DESESTRUCTURAMOS el bojeto "format" y le decimos lo que queremos usar, por que en realidad cuenta con mas.
const { combine, timestamp, printf, colorize } = winston.format

// el metodo print forma parte de winston, hay que instanciarlo
const formatoPersonalizado = printf(info => {
    return `[${info.timestamp}] ${info.level}: ${info.message}`
})

// creamos el objeto que hara de logger
const logger = winston.createLogger({
    level: "info",
    format: combine(timestamp(), formatoPersonalizado), // usamos nuestro formato personalizado creado
    transports: [
        // creamos el log de errores
        new winston.transports.File({
			level: "error",
			filename: `${configGeneral.rutaDirectorioLog}/error.log`,
			maxsize: configLog.maxTamano,
			maxFiles: configLog.maxArchivos
        }),
        // creamos el log para los demas mensajes
        new winston.transports.File({
			filename: `${configGeneral.rutaDirectorioLog}/combine.log`,
			maxsize: configLog.maxTamano,
			maxFiles: configLog.maxArchivos
        })
    ]
})

// creamos el que adicionara los logs
logger.add(new winston.transports.Console({
    level: "debug",
    format: combine(colorize(), timestamp(), formatoPersonalizado)
}))

// lo exportamos para poder usarlo donde queramos hacer un log
export { logger }